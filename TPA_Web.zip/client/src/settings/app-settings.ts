
export const APP_SETTINGS = {
    backend: 'http://localhost:8000',
    flask_backend: 'http://127.0.0.1:8080'
}