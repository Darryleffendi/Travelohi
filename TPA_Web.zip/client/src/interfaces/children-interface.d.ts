export default interface IChildren {
    children: JSX.Element
}