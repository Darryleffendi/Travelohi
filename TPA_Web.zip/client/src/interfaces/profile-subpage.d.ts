
export default interface IProfileSubpage {
    setLeftCard : (element : any) => void
}