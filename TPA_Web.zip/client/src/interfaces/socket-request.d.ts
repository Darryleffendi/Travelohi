export default interface ISocketRequest {
    request: string;
    keys? : object;
    sender ? : string;
}